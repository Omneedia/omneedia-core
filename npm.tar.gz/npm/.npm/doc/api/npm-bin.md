npm-bin(3) -- Display npm bin folder
====================================

## SYNOPSIS

    npm.commands.bin(args, cb)

## DESCRIPTION

Print the folder where npm will install executables.

This function should not be used programmatically.  Instead, just refer
to the `npm.bin` member.
